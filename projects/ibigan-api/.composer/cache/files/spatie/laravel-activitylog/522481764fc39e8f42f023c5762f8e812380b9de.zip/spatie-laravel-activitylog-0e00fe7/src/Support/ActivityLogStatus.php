<?php

namespace Spatie\Activitylog\Support;

use Illuminate\Contracts\Config\Repository;

class ActivityLogStatus
{
    protected bool $enabled = true;

    public function __construct(Repository $config)
    {
        $this->enabled = $config['activitylog.enabled'] ?? true;
    }

    public function enable(): bool
    {
        return $this->enabled = true;
    }

    public function disable(): bool
    {
        return $this->enabled = false;
    }

    public function disabled(): bool
    {
        return $this->enabled === false;
    }
}
